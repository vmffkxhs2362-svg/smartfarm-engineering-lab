#!/usr/bin/env python3
"""
OpenCEA CLI: Open-Source Commercial Controlled Environment Agriculture Engine
Author: Inwoovation Engineering Lab (contact@inwoovation.com)
License: MIT
Description: Command-line biophysics and CEA calculation engine for greenhouse 
             and vertical farm growers, engineers, and consultants.
"""

import sys
import math
import argparse
import json

def calculate_vpd(air_temp_c, rh_percent, leaf_temp_c=None):
    """
    Calculates Vapor Pressure Deficit (VPD) in kPa.
    If leaf_temp_c is None, assumes leaf temperature = air_temp_c - 2.0C (transpirational cooling).
    """
    if leaf_temp_c is None:
        leaf_temp_c = air_temp_c - 2.0
        
    # Tetens equation for saturation vapor pressure (kPa)
    svp_air = 0.61078 * math.exp((17.27 * air_temp_c) / (air_temp_c + 237.3))
    avp_air = svp_air * (rh_percent / 100.0)
    svp_leaf = 0.61078 * math.exp((17.27 * leaf_temp_c) / (leaf_temp_c + 237.3))
    
    vpd_leaf = svp_leaf - avp_air
    vpd_air = svp_air - avp_air
    
    # Agronomical zone classification
    if vpd_leaf < 0.4:
        status = "CRITICAL_LOW (High Fungal Pathogen & Guttation Risk)"
    elif 0.4 <= vpd_leaf < 0.8:
        status = "LOW_PROPAGATION (Ideal for Rooting / Seedlings)"
    elif 0.8 <= vpd_leaf <= 1.2:
        status = "OPTIMAL_GROWTH (Maximum Stomatal Conductance & Transpiration)"
    elif 1.2 < vpd_leaf <= 1.6:
        status = "MODERATE_STRESS (Generative Push, Monitor Water Stress)"
    else:
        status = "CRITICAL_HIGH (Stomatal Closure & Tip-Burn Risk)"
        
    return {
        "air_temp_c": air_temp_c,
        "leaf_temp_c": round(leaf_temp_c, 2),
        "rh_percent": rh_percent,
        "svp_air_kpa": round(svp_air, 4),
        "avp_air_kpa": round(avp_air, 4),
        "vpd_leaf_kpa": round(vpd_leaf, 3),
        "vpd_air_kpa": round(vpd_air, 3),
        "status": status
    }

def calculate_dli(ppfd_umol, photoperiod_hours):
    """
    Calculates Daily Light Integral (DLI) in mol/m2/day.
    Formula: DLI = PPFD * photoperiod * 3600 / 1,000,000
    """
    dli = ppfd_umol * photoperiod_hours * 3600.0 / 1e6
    
    if dli < 10.0:
        target = "Low Light Crops (Microgreens, Leafy Greens maintenance)"
    elif 10.0 <= dli < 16.0:
        target = "Commercial Leafy Greens & Culinary Herbs (Head Lettuce, Basil)"
    elif 16.0 <= dli < 25.0:
        target = "Commercial Strawberries & Nursery Seedlings"
    elif 25.0 <= dli < 35.0:
        target = "High-Wire Fruiting Vegetables (Tomato, Cucumber, Bell Pepper)"
    else:
        target = "Ultra-High Assimilation (Medicinal Cannabis, Supplemental Flowering)"
        
    return {
        "ppfd_umol_m2_s": ppfd_umol,
        "photoperiod_hours": photoperiod_hours,
        "dli_mol_m2_day": round(dli, 2),
        "recommended_crop_tier": target
    }

def calculate_heating_loss(floor_area_m2, t_indoor_c, t_outdoor_c, u_glass=6.5, thermal_screens=0, wind_speed_ms=4.0):
    """
    Estimates steady-state greenhouse transmission heat loss in kW.
    """
    # Envelope area approximation for standard Venlo glasshouse (envelope ~ 1.25 * floor)
    envelope_area = floor_area_m2 * 1.25
    delta_t = max(0.0, t_indoor_c - t_outdoor_c)
    
    effective_u = u_glass
    if thermal_screens == 1:
        effective_u *= 0.55  # 45% reduction
    elif thermal_screens >= 2:
        effective_u *= 0.38  # 62% reduction
        
    # Wind convective penalty (approx +2% per m/s over 4m/s)
    if wind_speed_ms > 4.0:
        effective_u *= (1.0 + 0.02 * (wind_speed_ms - 4.0))
        
    q_watts = effective_u * envelope_area * delta_t
    q_kw = q_watts / 1000.0
    specific_w_m2 = q_watts / floor_area_m2
    
    return {
        "floor_area_m2": floor_area_m2,
        "envelope_area_m2": round(envelope_area, 1),
        "t_indoor_c": t_indoor_c,
        "t_outdoor_c": t_outdoor_c,
        "delta_t_k": round(delta_t, 1),
        "effective_u_value_w_m2k": round(effective_u, 2),
        "total_heating_demand_kw": round(q_kw, 2),
        "specific_heating_demand_w_m2": round(specific_w_m2, 1)
    }

def calculate_co2_enrichment(floor_area_m2, ceiling_height_m, air_exchange_rate_h, target_ppm, ambient_ppm=420.0, crop_uptake_g_m2_h=25.0):
    """
    Calculates CO2 enrichment mass injection rate (kg/hr and g/m2/hr).
    Considers structural leakage/ventilation rate + active crop photosynthetic canopy uptake.
    CO2 density at standard temperature/pressure ~ 1.842 kg/m3.
    """
    canopy_volume_m3 = floor_area_m2 * ceiling_height_m
    delta_ppm = max(0.0, target_ppm - ambient_ppm)
    
    # Ventilation replacement volume of pure CO2 per hour (m3/h)
    co2_loss_m3_h = canopy_volume_m3 * air_exchange_rate_h * (delta_ppm * 1e-6)
    co2_loss_kg_h = co2_loss_m3_h * 1.842
    
    # Canopy photosynthesis assimilation uptake (kg/h)
    crop_uptake_kg_h = (floor_area_m2 * crop_uptake_g_m2_h) / 1000.0
    
    total_co2_kg_h = co2_loss_kg_h + crop_uptake_kg_h
    specific_dosing_g_m2_h = (total_co2_kg_h * 1000.0) / floor_area_m2
    
    return {
        "floor_area_m2": floor_area_m2,
        "ceiling_height_m": ceiling_height_m,
        "canopy_volume_m3": round(canopy_volume_m3, 1),
        "air_exchange_rate_ach": air_exchange_rate_h,
        "ambient_ppm": ambient_ppm,
        "target_ppm": target_ppm,
        "ventilation_loss_kg_h": round(co2_loss_kg_h, 2),
        "crop_photosynthetic_uptake_kg_h": round(crop_uptake_kg_h, 2),
        "total_co2_injection_kg_h": round(total_co2_kg_h, 2),
        "specific_dosing_rate_g_m2_h": round(specific_dosing_g_m2_h, 2)
    }

def calculate_fertigation_dosing(target_ec_ms, base_water_ec_ms=0.3, injection_ratio=100.0, target_volume_l=1000.0):
    """
    Calculates stock fertilizer injection concentration and dosage.
    Default standard: 1 mS/cm EC addition corresponds to ~640 PPM (500 scale) or ~1.0 g/L dry salts.
    """
    net_ec_addition = max(0.0, target_ec_ms - base_water_ec_ms)
    # Estimate total dissolved solids (TDS ppm 500 scale)
    est_tds_ppm = target_ec_ms * 500.0
    est_salts_g_l = net_ec_addition * 0.95  # approximate salt concentration per mS/cm
    
    # Required concentrated stock solution per tank volume (liters)
    # For a 1:injection_ratio injector (e.g. 1:100 Dosatron)
    stock_concentrate_volume_l = target_volume_l / injection_ratio
    total_dry_salts_kg = (est_salts_g_l * target_volume_l) / 1000.0
    stock_tank_density_g_l = total_dry_salts_kg * 1000.0 / stock_concentrate_volume_l
    
    return {
        "target_ec_ms_cm": target_ec_ms,
        "base_water_ec_ms_cm": base_water_ec_ms,
        "net_ec_addition_ms_cm": round(net_ec_addition, 2),
        "estimated_tds_ppm_500": round(est_tds_ppm, 1),
        "target_irrigation_volume_l": target_volume_l,
        "injector_ratio": f"1:{int(injection_ratio)}",
        "stock_concentrate_required_l": round(stock_concentrate_volume_l, 2),
        "total_dry_nutrients_kg": round(total_dry_salts_kg, 2),
        "stock_tank_concentration_g_l": round(stock_tank_density_g_l, 1)
    }

def calculate_led_thermal_load(fixture_wattage_w, fixture_count, efficacy_umol_j=2.8, photoperiod_hours=16.0):
    """
    Calculates horticultural LED PPF output and sensible HVAC thermal cooling demand.
    In indoor CEA, 100% of lighting electrical energy converts into sensible heat in steady state.
    """
    total_electrical_kw = (fixture_wattage_w * fixture_count) / 1000.0
    total_ppf_umol_s = fixture_wattage_w * fixture_count * efficacy_umol_j
    
    # Heat output
    sensible_heat_kw = total_electrical_kw
    heat_output_btu_h = total_electrical_kw * 3412.14
    tons_of_cooling = heat_output_btu_h / 12000.0
    daily_energy_kwh = total_electrical_kw * photoperiod_hours
    
    return {
        "fixture_wattage_w": fixture_wattage_w,
        "fixture_count": fixture_count,
        "efficacy_umol_j": efficacy_umol_j,
        "total_ppf_output_umol_s": round(total_ppf_umol_s, 1),
        "total_connected_load_kw": round(total_electrical_kw, 2),
        "sensible_cooling_demand_kw": round(sensible_heat_kw, 2),
        "sensible_cooling_demand_btu_h": round(heat_output_btu_h, 1),
        "required_cooling_tons": round(tons_of_cooling, 2),
        "daily_lighting_energy_kwh": round(daily_energy_kwh, 1)
    }

def main():
    parser = argparse.ArgumentParser(
        description="OpenCEA: Open-Source Commercial Horticultural & Greenhouse Engineering CLI"
    )
    subparsers = parser.add_subparsers(dest="command", help="Available calculation engines")
    
    # VPD parser
    vpd_parser = subparsers.add_parser("vpd", help="Calculate Leaf and Air Vapor Pressure Deficit (VPD)")
    vpd_parser.add_argument("--temp", type=float, required=True, help="Indoor Air Temperature (Celsius)")
    vpd_parser.add_argument("--rh", type=float, required=True, help="Relative Humidity (%%)")
    vpd_parser.add_argument("--leaf-temp", type=float, default=None, help="Leaf meristem temperature (Celsius, optional)")
    
    # DLI parser
    dli_parser = subparsers.add_parser("dli", help="Calculate Daily Light Integral (DLI)")
    dli_parser.add_argument("--ppfd", type=float, required=True, help="Photosynthetic Photon Flux Density (umol/m2/s)")
    dli_parser.add_argument("--hours", type=float, required=True, help="Photoperiod duration (hours/day)")
    
    # Heating parser
    heat_parser = subparsers.add_parser("heat", help="Estimate Greenhouse Transmission Heating Demand")
    heat_parser.add_argument("--area", type=float, required=True, help="Greenhouse floor footprint (m2)")
    heat_parser.add_argument("--tin", type=float, default=18.0, help="Indoor design temperature (Celsius)")
    heat_parser.add_argument("--tout", type=float, required=True, help="Outdoor ambient winter design temperature (Celsius)")
    heat_parser.add_argument("--screens", type=int, default=1, choices=[0, 1, 2], help="Number of active deployed thermal screens (0, 1, 2)")
    heat_parser.add_argument("--wind", type=float, default=4.0, help="Outdoor wind speed (m/s)")
    
    # CO2 parser
    co2_parser = subparsers.add_parser("co2", help="Calculate CO2 Enrichment Mass Injection Rate")
    co2_parser.add_argument("--area", type=float, required=True, help="Greenhouse or indoor floor area (m2)")
    co2_parser.add_argument("--height", type=float, default=4.5, help="Average ceiling height (m)")
    co2_parser.add_argument("--ach", type=float, default=0.5, help="Air change rate per hour (ACH)")
    co2_parser.add_argument("--target", type=float, default=1000.0, help="Target CO2 concentration (PPM)")
    co2_parser.add_argument("--ambient", type=float, default=420.0, help="Ambient outdoor CO2 concentration (PPM)")
    
    # Fertigation parser
    fert_parser = subparsers.add_parser("fert", help="Calculate Fertigation EC & Dilution Ratio")
    fert_parser.add_argument("--target-ec", type=float, required=True, help="Target feed EC (mS/cm)")
    fert_parser.add_argument("--base-ec", type=float, default=0.3, help="Source water EC (mS/cm)")
    fert_parser.add_argument("--ratio", type=float, default=100.0, help="Injector dilution ratio (e.g. 100 for 1:100)")
    fert_parser.add_argument("--volume", type=float, default=1000.0, help="Total irrigation batch volume (Liters)")
    
    # LED thermal parser
    led_parser = subparsers.add_parser("led", help="Calculate Horticultural LED PPF & Thermal Load")
    led_parser.add_argument("--watts", type=float, required=True, help="Electrical wattage per fixture (W)")
    led_parser.add_argument("--count", type=int, default=1, help="Number of fixtures")
    led_parser.add_argument("--ppe", type=float, default=2.8, help="Photosynthetic Photon Efficacy (umol/J)")
    led_parser.add_argument("--hours", type=float, default=16.0, help="Photoperiod hours/day")
    
    args = parser.parse_args()
    
    if args.command == "vpd":
        res = calculate_vpd(args.temp, args.rh, args.leaf_temp)
        print(json.dumps(res, indent=2))
    elif args.command == "dli":
        res = calculate_dli(args.ppfd, args.hours)
        print(json.dumps(res, indent=2))
    elif args.command == "heat":
        res = calculate_heating_loss(args.area, args.tin, args.tout, thermal_screens=args.screens, wind_speed_ms=args.wind)
        print(json.dumps(res, indent=2))
    elif args.command == "co2":
        res = calculate_co2_enrichment(args.area, args.height, args.ach, args.target, args.ambient)
        print(json.dumps(res, indent=2))
    elif args.command == "fert":
        res = calculate_fertigation_dosing(args.target_ec, args.base_ec, args.ratio, args.volume)
        print(json.dumps(res, indent=2))
    elif args.command == "led":
        res = calculate_led_thermal_load(args.watts, args.count, args.ppe, args.hours)
        print(json.dumps(res, indent=2))
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
