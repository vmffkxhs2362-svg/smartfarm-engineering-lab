# 🌱 OpenCEA: Commercial Controlled Environment Agriculture Physics Suite

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![Maintenance](https://img.shields.io/badge/Maintained%3F-yes-green.svg)](https://github.com/inwoovation)

OpenCEA is an open-source, zero-dependency biophysics and horticultural engineering calculation suite designed for commercial greenhouse operators, vertical farm engineers, agronomists, and CEA researchers.

---

## ⚡ 6 Core Biophysical Calculation Engines

1. **Vapor Pressure Deficit (VPD) Engine**: Calculates leaf and air VPD using Tetens formulations and transpirational offset kinetics. Classifies agronomical stress boundaries (Guttation risk vs. Stomatal closure).
2. **Daily Light Integral (DLI) Forecaster**: Quantifies cumulative daily photosynthetic photon flux (mol/m²/day) across photoperiods and supplemental lighting.
3. **Greenhouse Transmission Heating Model**: Sizes peak heating networks for standard Venlo glasshouses based on DIN V 18599/NEN 3859 with dynamic thermal screen attenuation.
4. **CO₂ Enrichment & Dosing Engine**: Computes required mass injection rate (kg/hr and g/m²/hr) factoring in structural ventilation leakage (ACH) and active canopy photosynthetic assimilation.
5. **Hydroponic Fertigation EC & Dilution Solver**: Balances stock tank concentration, injector ratios (e.g. 1:100), and target EC/TDS (PPM).
6. **Horticultural LED Heat & HVAC Load Simulator**: Translates fixture wattage and PPE (µmol/J) into total PPF output and sensible HVAC thermal cooling demand (kW & Tons of cooling).
7. **Zero External Dependencies**: Pure Python standard library CLI (`horti_cli.py`) + Single-file standalone HTML5 offline dashboard (`index.html`).

---

## 🚀 Quick Start

### 1. Command-Line Interface (Python CLI)

Clone the repository and run immediately with Python:

```bash
# 1. Calculate Vapor Pressure Deficit (VPD)
python horti_cli.py vpd --temp 24.5 --rh 70.0 --leaf-temp 22.5

# 2. Calculate Daily Light Integral (DLI)
python horti_cli.py dli --ppfd 350 --hours 16

# 3. Estimate Greenhouse Heating Loss (5000 m2 Venlo, 1 screen, -5C outside)
python horti_cli.py heat --area 5000 --tin 18.5 --tout -5.0 --screens 1

# 4. Calculate CO2 Enrichment Mass Injection Rate
python horti_cli.py co2 --area 1000 --height 4.5 --ach 0.5 --target 1000 --ambient 420

# 5. Calculate Fertigation Stock Solution Dosage
python horti_cli.py fert --target-ec 2.2 --base-ec 0.3 --ratio 100 --volume 1000

# 6. Calculate LED Photon Flux & HVAC Heat Rejection
python horti_cli.py led --watts 640 --count 20 --ppe 2.8 --hours 16
```

### 2. Offline Standalone Dashboard & 24/7 AI Agronomist Co-Pilot

Simply double-click `index.html` or open it in any modern web browser. No web server, Node.js, or internet connection required.

* **Embedded 24/7 Autonomous AI Agronomist Co-Pilot**: Translates ambiguous farmer questions (e.g. *"leaves curling and flowers dropping"*, *"strawberry heating in winter"*), automatically syncs and triggers the 6 calculation cards live, and provides actionable agronomic field management protocols.
* **1-Click Field Presets**: Instant diagnosis for VPD stress, heating peak demand, LED photoperiods, fertigation EC balancing, and CO2 enrichment.

---

## 💎 Enterprise Edition & Commercial Pro Pack

For commercial greenhouse operators, vertical farms, and engineering consultants, the **OpenCEA Pro Pack ($19)** includes:

1. **Standalone Offline Air-Gapped Package** (`OpenCEA-Pro-v1.0.0.zip`) for secure or zero-internet facility workstations.
2. **Commercial Perpetual License** (`COMMERCIAL_LICENSE.txt`) allowing internal engineering use and custom automation pipelines.
3. **Pure Biophysics Domain Kernel (`biophysics_kernel.js`) & Python CLI (`horti_cli.py`)** with full source code.
4. **Embedded 24/7 AI Agronomist Co-Pilot** for instant field stress diagnosis and 3-step actionable protocols.
5. **Lifetime Complimentary Updates**: Free permanent access to all newly developed calculators (33+ tools) and biophysical models.

👉 **[Get the OpenCEA Pro Pack ($19) on Polar.sh](https://buy.polar.sh/polar_cl_mRhSIZcW5YZGwh5QrSBVl1jLF8WeS8fZERjKk08f9LX)**

---

## 🛡️ 30-Day Money-Back Guarantee
We stand 100% behind the engineering rigor of our models. If the OpenCEA Pro Suite does not provide immediate, measurable value to your facility or engineering workflow, email `contact@inwoovation.com` within 30 days of purchase for a **100% full refund with no questions asked**.

---

## ⚖️ Limitation of Agricultural Liability
*OpenCEA Pro provides theoretical thermodynamic and biophysical simulation estimates based on published academic standards (DIN V 18599, ASAE EP411, FAO-56). In no event shall Inwoovation or the authors be held liable for any direct, indirect, incidental, or consequential crop loss, frost/freezing damage, physiological plant stress, equipment failure, or financial damages resulting from the use of this software. All simulation outputs must be independently validated by a licensed professional agronomist or facility engineer before physical implementation.*

---

## 🤖 Direct AI Agronomist & Technical Support
Have questions about your specific greenhouse dimensions, heating curves, or CLI automation?
- **Live Interactive AI Co-Pilot Desk**: https://inwoovation.com/suite/
- **Direct Engineering Support**: `contact@inwoovation.com`

---

## 📄 License & Attribution
Distributed under the OpenCEA Pro Commercial License (`COMMERCIAL_LICENSE.txt`). Maintained by **Inwoovation Engineering Lab**.
Website: https://inwoovation.com | Inquiries: `contact@inwoovation.com`
