# 🌱 OpenCEA: Commercial Controlled Environment Agriculture Physics Suite

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![Maintenance](https://img.shields.io/badge/Maintained%3F-yes-green.svg)](https://github.com/inwoovation)

OpenCEA is an open-source, zero-dependency biophysics and horticultural engineering calculation suite designed for commercial greenhouse operators, vertical farm engineers, agronomists, and CEA researchers.

---

## ⚡ 6 Core Biophysical Calculation Engines

1. **Vapor Pressure Deficit (VPD) Engine**: Calculates leaf and air VPD using Tetens formulations and transpirational offset kinetics. Classifies agronomical stress boundaries (Guttation risk vs. Stomatal closure).
2. **Daily Light Integral (DLI) Forecaster**: Quantifies cumulative daily photosynthetic photon flux (mol/m²/day) across photoperiods and supplemental lighting.
3. **Greenhouse Transmission Heating Model**: Sizes peak heating networks for standard Venlo glasshouses based on DIN V 18599/NEN 3859 with dynamic thermal screen attenuation.
4. **CO₂ Enrichment & Dosing Engine**: Computes required mass injection rate (kg/hr and g/m²/hr) factoring in structural ventilation leakage (ACH) and active canopy photosynthetic assimilation.
5. **Hydroponic Fertigation EC & Dilution Solver**: Balances stock tank concentration, injector ratios (e.g. 1:100), and target EC/TDS (PPM).
6. **Horticultural LED Heat & HVAC Load Simulator**: Translates fixture wattage and PPE (µmol/J) into total PPF output and sensible HVAC thermal cooling demand (kW & Tons of cooling).
7. **Zero External Dependencies**: Pure Python standard library CLI (`horti_cli.py`) + Single-file standalone HTML5 offline dashboard (`index.html`).

---

## 🚀 Quick Start

### 1. Command-Line Interface (Python CLI)

Clone the repository and run immediately with Python:

```bash
# 1. Calculate Vapor Pressure Deficit (VPD)
python horti_cli.py vpd --temp 24.5 --rh 70.0 --leaf-temp 22.5

# 2. Calculate Daily Light Integral (DLI)
python horti_cli.py dli --ppfd 350 --hours 16

# 3. Estimate Greenhouse Heating Loss (5000 m2 Venlo, 1 screen, -5C outside)
python horti_cli.py heat --area 5000 --tin 18.5 --tout -5.0 --screens 1

# 4. Calculate CO2 Enrichment Mass Injection Rate
python horti_cli.py co2 --area 1000 --height 4.5 --ach 0.5 --target 1000 --ambient 420

# 5. Calculate Fertigation Stock Solution Dosage
python horti_cli.py fert --target-ec 2.2 --base-ec 0.3 --ratio 100 --volume 1000

# 6. Calculate LED Photon Flux & HVAC Heat Rejection
python horti_cli.py led --watts 640 --count 20 --ppe 2.8 --hours 16
```

### 2. Offline Standalone Dashboard & 24/7 AI Agronomist Co-Pilot

Simply double-click `index.html` or open it in any modern web browser. No web server, Node.js, or internet connection required.

* **Embedded 24/7 Autonomous AI Agronomist Co-Pilot**: Translates ambiguous farmer questions (e.g. *"leaves curling and flowers dropping"*, *"strawberry heating in winter"*), automatically syncs and triggers the 6 calculation cards live, and provides actionable agronomic field management protocols.
* **1-Click Field Presets**: Instant diagnosis for VPD stress, heating peak demand, LED photoperiods, fertigation EC balancing, and CO2 enrichment.

---

## 💎 Enterprise Edition & Commercial Pro Pack

For enterprise greenhouse consulting firms and commercial farm engineering teams, the **Inwoovation Pro Suite** includes:

1. **All 33 Commercial Engineering Simulators** (Full offline source code package).
2. **Sonneveld & Steiner Hydroponic Ion Balance Solvers** with automated fertilizer dosing recipes.
3. **Model Predictive Control (MPC) Python Microclimate Simulator**.
4. **Excel VBA / Macro Toolkits** for commercial greenhouse OPEX budgeting.

👉 **[Get the OpenCEA Pro Pack ($19) on Polar.sh](https://buy.polar.sh/polar_cl_mRhSIZcW5YZGwh5QrSBVl1jLF8WeS8fZERjKk08f9LX)**

---

## 📄 License & Attribution

Distributed under the **MIT License**. Maintained by **Inwoovation Engineering Lab** (`contact@inwoovation.com`).
Contributions, issues, and feature requests are welcome!
